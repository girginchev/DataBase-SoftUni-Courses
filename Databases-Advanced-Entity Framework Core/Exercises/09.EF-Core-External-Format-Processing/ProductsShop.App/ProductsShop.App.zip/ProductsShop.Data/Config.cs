﻿namespace ProductsShop.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Config
    {
        public const string ConnectinString = "Server=.;Database=ProductsShopDb;Integrated Security=true";
    }
}
